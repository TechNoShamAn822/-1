﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication53
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Калькулятор");
            Console.WriteLine("----------------------");
            Console.WriteLine("Введите первый элемент");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите второй элемент");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("выберите тип операции");
            char c = char.Parse(Console.ReadLine());
            double d = 0;
            switch (c)
            {
                case '+':
                    d = a + b;
                    break;
                case '-':
                    d = a - b;
                    break;
                case '/':
                    d = a / b;
                    break;
                case '*':
                    d = a * b;
                    break;

            }
            Console.WriteLine(d);
            Console.ReadKey();




        }
    }
}
